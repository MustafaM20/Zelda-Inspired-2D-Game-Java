//Name- Mustafa Majeed and Ammar A
//Date 1/19/2024
//Class : UserInterface
//Package main
package userInterface;

import java.awt.Color; //imports
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import java.awt.BasicStroke;
import java.awt.Graphics2D;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;

public class UserInterface {

	public int playerHealth1; //variable declaration
	public int damageTaken1;
	public int enemyhealth1;
	public BufferedImage health;
	public int level1;
	public int demon2health;
	

	public UserInterface(int playerHealth, int damagetaken, int enemyHealth, int level, int demon2Health) {
		playerHealth1 = playerHealth; //giving all the variable starting values
		damageTaken1 = damagetaken;
		enemyhealth1 = enemyHealth;
		level1 = level;
		getIconImages(); //get all the images we need
	}

	public void getIconImages() {
		try {
			health = ImageIO.read(getClass().getResourceAsStream("/player/heart.png")); //get the image
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void draw(Graphics2D g2) {
		BufferedImage image = null;
	
        image = health; //makes image variable
        g2.setColor(Color.YELLOW);
        
        g2.setColor(Color.BLACK); //prints the variable
        g2.setFont(new Font("Arial", Font.BOLD, 60)); 
        g2.drawString("Level: " + level1, 340, 90);
        
        if(playerHealth1 > 400) { //depending on character, the amount of hearts it pastes.
        	for(int i = 750; i > 500; i-=50) {
        	g2.drawImage(image, 50 + i, 30, 40, 40,null);
        }
        }
        else if(playerHealth1 > 300) {
            	for(int i = 750; i > 550; i-=50) {
            	g2.drawImage(image, 50 + i, 30, 40, 40,null);
            }
        }
		else if (playerHealth1 > 200) {
			for (int i = 750; i > 600; i -=50) {
				g2.drawImage(image, 50 + i, 30, 40, 40, null);
			}
		}
		else if (playerHealth1 > 100) {
			for (int i = 750; i > 650; i -=50) {
				g2.drawImage(image, 50 + i, 30, 40, 40, null);
			}
		}
		else if (playerHealth1 > 0) {
			for (int i = 750; i > 700; i -=50) {
				g2.drawImage(image, 50 + i, 30, 40, 40, null);
			}
		}

	}

	public void update(int playerHealth, int damagetaken, int enemyHealth, int level, int demon2Health) {
		playerHealth1 = playerHealth; //updates the healths, for the game
		damageTaken1 = damagetaken;
		enemyhealth1 = enemyHealth;
		level1 = level;
		demon2health = demon2Health;
	}


}
