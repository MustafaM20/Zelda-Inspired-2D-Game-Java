//Name- Mustafa Majeed and Ammar A
//Date 1/19/2024
//Class : Fireball 2
//Package attacks
//It's the same as fireball1 but the direction of the fireball is different from each random number
package attacks;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import entity.Demon;
import main.GamePanel;
import main.KeyHandler;

public class Fireball2 {

	public int x, y;
	public int speed;
	GamePanel gp;

	int ticker;
	public int imageNum;
	
	public BufferedImage f1, f2, f3, f4, f5;

	public int spriteCounter = 0;
	public int spriteNum = 1;
	public int alternating = 1;
	

	public Fireball2(GamePanel gp) {
		this.gp = gp;
		setDefaultValues();
		getPlayerImage();
	}

	public void getPlayerImage() {
		try {
			f1 = ImageIO.read(getClass().getResourceAsStream("/fireball/FB001.png"));
			f2 = ImageIO.read(getClass().getResourceAsStream("/fireball/FB002.png"));
			f3 = ImageIO.read(getClass().getResourceAsStream("/fireball/FB003.png"));
			f4 = ImageIO.read(getClass().getResourceAsStream("/fireball/FB004.png"));
			f5 = ImageIO.read(getClass().getResourceAsStream("/fireball/FB005.png"));

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void setDefaultValues() {
		x = Demon.xDemon;
		y = Demon.yDemon;
		speed = 7;
		imageNum = 1;
		alternating = (int) (Math.random() * (4 - 1 + 1) + 1);
	}
	
	public void draw(Graphics2D g2) {
		BufferedImage image = null;
		
		if(imageNum == 1) {
			image = f1;
		}
		else if(imageNum == 2) {
			image = f2;
		}
		else if(imageNum == 3) {
			image = f3;
		}
		else if(imageNum == 4) {
			image = f4;
		}
		else if(imageNum ==5) {
			image = f5;
		}
		else if(imageNum == 6) {
			image = null;
		}
		g2.drawImage(image, x, y, 100, 100,null);
  }
	
public void update() {
	
		if (alternating == 4) {
			y -= speed;
			imageNum += 1;
			if (imageNum == 6) {
				imageNum = 1;
			}

			if (y < 0) {
				setDefaultValues();
			}
		} else if (alternating == 1) {

			y += speed;
			imageNum += 1;
			if (imageNum == 6) {
				imageNum = 1;
			}

			if (y > 700) {
				setDefaultValues();
			}
		} else if (alternating == 2) {

			x = x - speed;
			imageNum += 1;
			if (imageNum == 6) {
				imageNum = 1;
			}

			if (x < 0) {
				setDefaultValues();
			}
		} else if (alternating == 3) {

			x += speed;
			imageNum += 1;
			if (imageNum == 6) {
				imageNum = 1;
			}

			if (x > 700) {
				setDefaultValues();
			}
		}

	}

public Rectangle getBounds() {
	return new Rectangle(x, y, 20, 20);
}

}


