//Name- Mustafa Majeed and Ammar A
//Date 1/19/2024
//Class : Fireball 1
//Package attacks

package attacks;

import java.awt.Graphics2D; //all the imports
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import entity.Demon;
import main.GamePanel;
import main.KeyHandler;

public class Fireball {

	public int x, y; // variable declaration
	public int speed;
	GamePanel gp;
	Rectangle bounds;

	int ticker;

	public BufferedImage f1, f2, f3, f4, f5;

	public int spriteCounter = 0;
	public int spriteNum = 1;
	public int alternating = 1;
	public int imageNum;

	public Fireball(GamePanel gp) { // constructor
		this.gp = gp; // set all the default values for the fireballs
		setDefaultValues();
		getPlayerImage();
	}

	public void getPlayerImage() {
		try {
			f1 = ImageIO.read(getClass().getResourceAsStream("/fireball/FB001.png")); // establish all of the iages for
																						// a fireball
			f2 = ImageIO.read(getClass().getResourceAsStream("/fireball/FB002.png"));
			f3 = ImageIO.read(getClass().getResourceAsStream("/fireball/FB003.png"));
			f4 = ImageIO.read(getClass().getResourceAsStream("/fireball/FB004.png"));
			f5 = ImageIO.read(getClass().getResourceAsStream("/fireball/FB005.png"));

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void setDefaultValues() {
		x = Demon.xDemon;
		y = Demon.yDemon;
		speed = 7;
		imageNum = 1;
		alternating = (int) (Math.random() * (4 - 1 + 1) + 1); // the direction the fireball is shot is decided in
																// random
	}

	public void draw(Graphics2D g2) {
		BufferedImage image = null; // draws the fireball

		if (imageNum == 1) { // the iamge of the fireball is what part of the animation is the fireball in.
								// It's done quickly to show movement
			image = f1;
		} else if (imageNum == 2) {
			image = f2;
		} else if (imageNum == 3) {
			image = f3;
		} else if (imageNum == 4) {
			image = f4;
		} else if (imageNum == 5) {
			image = f5;
		} else if (imageNum == 6) {
			image = null;
		}
		g2.drawImage(image, x, y, 100, 100, null);
	}

	public void update() {

		if (alternating == 1) { // if its 1, the fireball upwards
			y -= speed;
			imageNum += 1;
			if (imageNum == 6) {
				imageNum = 1;
			}

			if (y < 0) {
				setDefaultValues();
			}
		} else if (alternating == 2) { // if its 2, the fireball goes down

			y += speed;
			imageNum += 1;
			if (imageNum == 6) {
				imageNum = 1;
			}

			if (y > 860) {
				setDefaultValues();
			}
		} else if (alternating == 3) { // if its 3, the fireball goes left

			x = x - speed;
			imageNum += 1;
			if (imageNum == 6) {
				imageNum = 1;
			}

			if (x < 0) {
				setDefaultValues();
			}
		} else if (alternating == 4) { // if its 4, the fireball goes right

			x += speed;
			imageNum += 1;
			if (imageNum == 6) {
				imageNum = 1;
			}

			if (x > 860) {
				setDefaultValues(); // after the fireball is shot, the values are reset again
			}
		}

	}

	public Rectangle getBounds() { // hitbox for fireball
		return new Rectangle(x, y, 20, 20);
	}

}
