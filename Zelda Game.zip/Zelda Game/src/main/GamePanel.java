//Name- Mustafa Majeed and Ammar A
//Date 1/19/2024
//Package : Main
//Game Panel Class
package main;

import java.awt.*; //imports
import java.awt.event.*;
import java.io.IOException;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import attacks.Fireball;
import attacks.Fireball2;
import attacks.Fireball3;
import attacks.Fireball4;
import attacks.Fireball5;
import attacks.Fireball6;

import java.awt.event.KeyEvent;

import entity.Demon;
import entity.Demon2;
import entity.Demon3;
import entity.Player;
import entity.WindSpellRight;
import entity.WindSpellUp;
import userInterface.UserInterface;
import entity.WindSpellDown;
import entity.WindSpellLeft;

public class GamePanel extends JPanel implements Runnable {

	public static final int GAME_WIDTH = 850; // game size
	public static final int GAME_HEIGHT = 850;

	// variable declaration
	KeyHandler keyH = new KeyHandler();

	Thread gameThread;

	public BufferedImage backgroundImage;

	public BufferedImage backgroundImageLevel2;

	public BufferedImage backgroundImagelevel3;

	public BufferedImage titleScreen;

	public BufferedImage secondScreen;

	public BufferedImage thirdScreen;

	public BufferedImage fourthScreen;

	public BufferedImage instructions;

	public BufferedImage endScreen;

	int FPS = 60;

	int playerHealth = 500;
	int damagetaken = 0;
	int demon1Health = 200;
	int demon1HitCounter = 0;
	int demon2Health = 200;
	int demon2HitCounter = 0;
	int demon3Health = 200;
	int demon3HitCounter = 0;

	public int gameState = 0;

	public int level = 1;

	Player player = new Player(this, keyH);

	Sound sound = new Sound();

	Demon demon = new Demon(this);

	Demon2 demon2 = new Demon2(this);

	Demon3 demon3 = new Demon3(this);

	Fireball fireball = new Fireball(this);

	UserInterface ui = new UserInterface(playerHealth, damagetaken, demon1Health, level, demon2Health); // creates our
	// score object

	Fireball2 fireball2 = new Fireball2(this);

	Fireball3 fireball3 = new Fireball3(this);

	Fireball4 fireball4 = new Fireball4(this);

	Fireball5 fireball5 = new Fireball5(this);

	Fireball6 fireball6 = new Fireball6(this);

	WindSpellRight windspell = new WindSpellRight(this, keyH);

	WindSpellLeft windspell2 = new WindSpellLeft(this, keyH);

	WindSpellUp windspell3 = new WindSpellUp(this, keyH);

	WindSpellDown windspell4 = new WindSpellDown(this, keyH);

	public GamePanel() { // main panel
		this.setFocusable(true);
		this.addKeyListener(keyH); // start listening for keyboard input
		this.setPreferredSize(new Dimension(GAME_WIDTH, GAME_HEIGHT));
		gameThread = new Thread(this);
		gameThread.start(); // start gameThread
		try { // importing all the background images
			backgroundImage = ImageIO.read(getClass().getResourceAsStream("/player/backgroundImage.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			backgroundImageLevel2 = ImageIO.read(getClass().getResourceAsStream("/player/2ndBackground.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			backgroundImagelevel3 = ImageIO.read(getClass().getResourceAsStream("/player/3rdbackground.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			titleScreen = ImageIO.read(getClass().getResourceAsStream("/player/titleScreen.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			secondScreen = ImageIO.read(getClass().getResourceAsStream("/player/secondCut.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			thirdScreen = ImageIO.read(getClass().getResourceAsStream("/player/3rdcut.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			fourthScreen = ImageIO.read(getClass().getResourceAsStream("/player/4thcut.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			instructions = ImageIO.read(getClass().getResourceAsStream("/player/instructions.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			endScreen = ImageIO.read(getClass().getResourceAsStream("/player/ending.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void startGameThread() {
		gameThread = new Thread(this);
		gameThread.start();
	}

	public void run() { // where the gam eruns

		long lastTime = System.nanoTime();
		double amountOfTicks = 60;
		double ns = 1000000000 / amountOfTicks;
		double delta = 0;
		long now;
		int secondCount = 0;

		while (true) {
			now = System.nanoTime();
			delta = delta + (now - lastTime) / ns;
			lastTime = now;

			if (delta >= 1) { // delta counter
				if (secondCount == 0) {
					try {
						Sound.playBackground();
					} catch (LineUnavailableException | IOException | UnsupportedAudioFileException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				try {
					update();
				} catch (LineUnavailableException | IOException | UnsupportedAudioFileException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					collision();
				} catch (LineUnavailableException | IOException | UnsupportedAudioFileException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (damagetaken > 0 || demon1HitCounter > 0 || demon2HitCounter > 0 || demon3HitCounter > 0) { // run
																												// damageCalculator
																												// //
																												// hit
					try {
						damageCalculator();
					} catch (LineUnavailableException | IOException | UnsupportedAudioFileException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
				if (demon1Health <= 0 && level == 1) {
					level = level + 1; // if first demon dies, go to next level
					gameResetLevel();
				}
				if (demon1Health <= 0 && level == 2 && demon2Health <= 0) { // if both demons die, go to level 3
					level = level + 1;
					gameResetLevel();
				}
				if (demon1Health <= 0 && level == 3 && demon2Health <= 0 && demon3Health <= 0) { // if all demons die on
																									// level 3, game
																									// ends
					gameState = 6;
				}
				if (demon2Health <= 0 && level == 2) { // "kills the demon"
					demon2.level2 = false;
				}
				if (demon1Health <= 0 && level == 2) { // "kills the demon by hiding it.
					demon.alive = false;
				}
				if (demon2Health <= 0 && level == 2) { // same thing again
					demon2.level2 = false;
				}
				if (demon1Health <= 0 && level == 3) {
					demon.alive = false;
				}
				if (demon2Health <= 0 && level == 3) {
					demon2.level2 = false;
				}
				if (demon3Health <= 0 && level == 3) {
					demon3.level3 = false;
				}

				repaint();
				if (playerHealth <= 0) { // if player dies, repeat the level
					gameResetLevel();
				}
				secondCount++;
				if (secondCount == 3000) {
					secondCount = 0;
				}
				delta--;
			}

		}
	}

	public void gameResetLevel() {
		if (level == 1) { // all reset qualities for every level
			playerHealth = 500;
			damagetaken = 0;
			demon1Health = 200;
			demon1HitCounter = 0;
			player.x = 100;
			player.y = 100;
			demon.x = 600;
			demon.y = 600;
		} else if (level == 2) {
			demon2.level2 = true; // hide the fireballs and demon until level is reached
			fireball3.show = true;
			fireball4.show = true;
			playerHealth = 500;
			damagetaken = 0;
			demon1Health = 200;
			demon1HitCounter = 0;
			demon2Health = 200;
			demon2HitCounter = 0;
			player.x = 100;
			player.y = 100;
			demon.x = 600;
			demon.y = 600;
			demon2.x = 800;
			demon2.y = 300;
		} else if (level == 3) {
			demon2.level2 = true; // hide the fireball and demon until level is reached
			fireball3.show = true;
			fireball4.show = true;
			demon3.level3 = true;
			fireball5.show = true;
			fireball6.show = true;
			demon.alive = true;
			playerHealth = 500;
			damagetaken = 0;
			demon1Health = 200;
			demon1HitCounter = 0;
			demon2Health = 200;
			demon2HitCounter = 0;
			demon3Health = 200;
			demon3HitCounter = 0;
			player.x = 100;
			player.y = 100;
			demon.x = 600;
			demon.y = 600;
			demon2.x = 800;
			demon2.y = 300;
			demon3.y = 200;
			demon3.x = 740;
		}
	}

	public void update() throws LineUnavailableException, IOException, UnsupportedAudioFileException {
		player.update(); // update the positions of every class
		demon.update();
		demon2.update();
		demon3.update();
		fireball.update();
		fireball2.update();
		fireball3.update();
		fireball4.update();
		fireball5.update();
		fireball6.update();
		windspell3.update();
		windspell.update();
		windspell2.update();
		windspell4.update();
		ui.update(playerHealth, damagetaken, demon1Health, level, demon2Health);
	}

	public void collision() throws LineUnavailableException, IOException, UnsupportedAudioFileException {
		if (player.getBounds().intersects(fireball.getBounds())) { // all the collisoin effects
			fireball.imageNum = 6; // these are all about player geting hit by the fireball
			damagetaken += 1;

		}

		if (player.getBounds().intersects(fireball2.getBounds())) {
			fireball2.imageNum = 6;
			damagetaken += 1;
		}

		if (player.getBounds().intersects(fireball3.getBounds())) {
			fireball3.imageNum = 6;
			damagetaken += 1;
		}

		if (player.getBounds().intersects(fireball4.getBounds())) {
			fireball4.imageNum = 6;
			damagetaken += 1;
		}

		if (player.getBounds().intersects(fireball5.getBounds())) {
			fireball3.imageNum = 6;
			damagetaken += 1;
		}

		if (player.getBounds().intersects(fireball6.getBounds())) {
			fireball4.imageNum = 6;
			damagetaken += 1;
		}

		if (player.getBounds2().intersects(demon.getBounds2()) && player.attackNum == 1 && keyH.spacePressed == false) {
			demon1HitCounter += 1; // these ones relate to the player using his sword to attack. its basically
									// saying you should have clicked space but now space is unclicked. it's kind of
									// a way to make sure u don't hold attack
		}

		if (player.getBounds2().intersects(demon2.getBounds2()) && player.attackNum == 1
				&& keyH.spacePressed == false) {
			demon2HitCounter += 1;
		}

		if (player.getBounds2().intersects(demon3.getBounds2()) && player.attackNum == 1
				&& keyH.spacePressed == false) {
			demon3HitCounter += 1;
		}

		if (player.getBounds().intersects(demon.getBounds()) || player.getBounds().intersects(demon2.getBounds())
				| player.getBounds().intersects(demon3.getBounds2())) { // if the playe gets touched by the demon, they
																		// // are damages. its their way of stabbing
			damagetaken += 1;
		}

		if (windspell.getBounds().intersects(demon.getBounds2()) // if the windspell hits the demon it damages them
				|| windspell2.getBounds().intersects(demon.getBounds2())
				|| windspell3.getBounds().intersects(demon.getBounds2())
				|| windspell4.getBounds().intersects(demon.getBounds2())) {
			demon1HitCounter += 3;
		}

		if (windspell.getBounds().intersects(demon2.getBounds2())
				|| windspell2.getBounds().intersects(demon2.getBounds2())
				|| windspell3.getBounds().intersects(demon2.getBounds2())
				|| windspell4.getBounds().intersects(demon2.getBounds2())) {
			demon2HitCounter += 3;
		}

		if (windspell.getBounds().intersects(demon3.getBounds2())
				|| windspell2.getBounds().intersects(demon3.getBounds2())
				|| windspell3.getBounds().intersects(demon3.getBounds2())
				|| windspell4.getBounds().intersects(demon3.getBounds2())) {
			demon3HitCounter += 3;
		}

		if (player.x < 1) { // these are all to make sure the player doesn't go off the map. the demons
							// never go off the game panel because they keep walking towards the player
			player.x = player.x + player.speed;
		}

		if (player.x > 800) {
			player.x = player.x - player.speed;
		}

		if (player.y <= 4) {
			player.y += player.speed;
		}

		if (player.y >= 800) {
			player.y -= player.speed;
		}

	}

	public void damageCalculator() throws LineUnavailableException, IOException, UnsupportedAudioFileException { // all
																													// the
																													// damage
																													// calculators

		if (demon1HitCounter > 0 | demon2HitCounter > 0 || demon3HitCounter > 0)
			if (demon1HitCounter > 0) {
				demon1Health -= demon1HitCounter;
				demon1HitCounter = 0; // after adding the damage it always resets the hit counter again
			}
		if (demon2HitCounter > 0) {
			demon2Health -= demon2HitCounter;
			demon2HitCounter = 0;
		}
		if (demon3HitCounter > 0) {
			demon3Health -= demon3HitCounter;
			demon3HitCounter = 0;
		} else {
			playerHealth = playerHealth - 1;
			damagetaken = 0;
		}
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g); // this is where all the drawings of the sprites occur

		Graphics2D g2 = (Graphics2D) g;

		if (gameState == 0) { // draws the background depending on what state the game is in
			if (backgroundImage != null && level == 1) {
				g2.drawImage(titleScreen, 0, 0, 850, 850, this);
			}
			if (keyH.enterKey == true) { // u must click the key to proceed
				gameState = gameState + 1;
			}
		}
		if (gameState == 1) {
			if (backgroundImage != null && level == 1) {
				g2.drawImage(secondScreen, 0, 0, 850, 850, this);
			}
			if (keyH.lkey == true) { // u must click the key to proceed
				gameState = gameState + 1;
			}
		}
		if (gameState == 2) {
			if (backgroundImage != null && level == 1) {
				g2.drawImage(thirdScreen, 0, 0, 850, 850, this);
			}
			if (keyH.okey == true) { // u must click the key to proceed
				gameState = gameState + 1;
			}
		}

		if (gameState == 3) {
			if (backgroundImage != null && level == 1) {
				g2.drawImage(fourthScreen, 0, 0, 850, 850, this);
			}
			if (keyH.ikey == true) { // u must click the key to proceed
				gameState = gameState + 1;
			}
		}
		if (gameState == 4) {
			if (backgroundImage != null && level == 1) {
				g2.drawImage(instructions, 0, 0, 850, 850, this);
			}
			if (keyH.ukey == true) { // u must click the key to proceed
				gameState = gameState + 1;
				gameResetLevel();
			}
		}

		if (gameState == 5) {
			if (backgroundImage != null && level == 1) {
				g2.drawImage(backgroundImage, 0, 0, 850, 850, this);
			}
			if (backgroundImage != null && level == 2) {
				g2.drawImage(backgroundImageLevel2, 0, 0, 900, 850, this);
			}
			if (backgroundImage != null && level == 3) {
				g2.drawImage(backgroundImagelevel3, 0, 0, 850, 850, this);
			}

			try {
				player.draw(g2);
			} catch (LineUnavailableException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (UnsupportedAudioFileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} // draws everything
			demon.draw(g2);
			demon2.draw(g2);
			demon3.draw(g2);
			windspell3.draw(g2);
			fireball.draw(g2);
			fireball2.draw(g2);
			fireball3.draw(g2);
			fireball4.draw(g2);
			fireball5.draw(g2);
			fireball6.draw(g2);
			windspell.draw(g2);
			windspell4.draw(g2);
			windspell2.draw(g2);
			ui.draw(g2);
			g2.dispose();
		}
		if (gameState == 6) {
			if (backgroundImage != null && level == 3) {
				g2.drawImage(endScreen, 0, 0, 850, 850, this);
			}
		}
	}
}