//Name- Mustafa Majeed and Ammar A
//Date 1/19/2024
//Class : Main
//KeyEvent Class
//Package Main
package main;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;//imports

public class KeyHandler implements KeyListener {

  public boolean upPressed, downPressed, leftPressed, rightPressed, spacePressed, arrowLeft, arrowRight, arrowUp,
  arrowDown, enterKey, lkey, pkey, ikey, okey, ukey; //variable declaration

  public void keyTyped(KeyEvent e) {

  }

  public void keyPressed(KeyEvent e) {
    // these all keyboard inputs. if that key is clicked the boolean is true
    int code = e.getKeyCode();

    if (code == KeyEvent.VK_W) {
      upPressed = true;
    }

    if (code == KeyEvent.VK_S) {
      downPressed = true;
    }

    if (code == KeyEvent.VK_A) {
      leftPressed = true;
    }

    if (code == KeyEvent.VK_D) {
      rightPressed = true;
    }

    if (code == KeyEvent.VK_SPACE) {
      spacePressed = true;
    }

    if (code == KeyEvent.VK_LEFT) {
      arrowLeft = true;
    }

    if (code == KeyEvent.VK_UP) {
      arrowUp = true;
    }

    if (code == KeyEvent.VK_RIGHT) {
      arrowRight = true;
    }

    if (code == KeyEvent.VK_DOWN) {
      arrowDown = true;
    }

    if (code == KeyEvent.VK_ENTER) {
      enterKey = true;
    }

    if (code == KeyEvent.VK_L) {
      lkey = true;
    }
    
    if (code == KeyEvent.VK_P) {
        pkey = true;
      }
      if (code == KeyEvent.VK_O) {
          okey = true;
      }
      if (code == KeyEvent.VK_I) {
          ikey = true;
      }
      
      if (code == KeyEvent.VK_U) {
          ukey = true;
      }
    }


  public void keyReleased(KeyEvent e) {
    // when the key is released the booleans goes back to being false.
    int code = e.getKeyCode();

    if (code == KeyEvent.VK_W) {
      upPressed = false;

    }

    if (code == KeyEvent.VK_S) {
      downPressed = false;
    }

    if (code == KeyEvent.VK_A) {
      leftPressed = false;
    }

    if (code == KeyEvent.VK_D) {
      rightPressed = false;
    }

    if (code == KeyEvent.VK_SPACE) {
      spacePressed = false;
    }

    if (code == KeyEvent.VK_LEFT) {
      arrowLeft = false;
    }

    if (code == KeyEvent.VK_UP) {
      arrowUp = false;
    }

    if (code == KeyEvent.VK_RIGHT) {
      arrowRight = false;
    }

    if (code == KeyEvent.VK_DOWN) {
      arrowDown = false;
    }

    if (code == KeyEvent.VK_ENTER) {
      enterKey = false;
    }
    if (code == KeyEvent.VK_L) {
      lkey = false;
    }
    if (code == KeyEvent.VK_L) {
        pkey = false;
    }
    if (code == KeyEvent.VK_L) {
        okey = false;
    }
    if (code == KeyEvent.VK_L) {
        ikey = false;
    } 
    if (code == KeyEvent.VK_U) {
        ukey = false;
    }
  }
}
