//Name- Mustafa Majeed and Ammar A
//Date 1/19/2024
//Class : Main
//Package main
package main;

public class Main {
  public static void main(String[] args) {
    new GameFrame();  //runs the game frame, which then runs game panel
   
  }
}