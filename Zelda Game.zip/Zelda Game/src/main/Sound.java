package main;

import java.io.File;
import java.io.IOException;
import javax.sound.sampled.*;

public class Sound {
	
    static File swordSlash = new File("swordslash.wav");
    
    static File windSpell = new File("windSpell.wav");
    
    static File backGround = new File("backGroundMusic.wav");
    
    public static void playSwordSlash() throws LineUnavailableException, IOException, UnsupportedAudioFileException {
        // Use the static variable in the method
        AudioInputStream audioStream = AudioSystem.getAudioInputStream(swordSlash);
        Clip clip = AudioSystem.getClip();
        clip.open(audioStream);
        clip.start();
    }
    
    public static void playwindSpell() throws LineUnavailableException, IOException, UnsupportedAudioFileException {
        // Use the static variable in the method
        AudioInputStream audioStream = AudioSystem.getAudioInputStream(windSpell);
        Clip clip = AudioSystem.getClip();
        clip.open(audioStream);
        clip.start();
    }
    
    public static void playBackground() throws LineUnavailableException, IOException, UnsupportedAudioFileException {
        AudioInputStream audioStream = AudioSystem.getAudioInputStream(backGround);
        Clip clip = AudioSystem.getClip();
        clip.open(audioStream);
        clip.start();
    }
}
