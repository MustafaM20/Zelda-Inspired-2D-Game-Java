//Name- Mustafa Majeed and Ammar A
//Date 1/19/2024
//Class : wind spell up
//Package Entity

//This class works the exact same as the down wind spell one. Only the calcualation of the co-ordinates is different.
package entity;

import java.awt.*;
import main.GameFrame;
import main.GamePanel;
import main.KeyHandler;
import main.Sound;

import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;

public class WindSpellLeft extends Entity {

	Rectangle bounds;
	GamePanel gp;
	KeyHandler keyH;
	public int attackNum;
	public int imageNum;
	public boolean shootSpell;
	public int ticker;

	public WindSpellLeft(GamePanel gp, KeyHandler keyH) {
		this.gp = gp;
		this.keyH = keyH;
		setDefaultValues();
		getPlayerImage();	
	}

	public void setDefaultValues() {
		x = 100;
		y = 100;
		speed = 40;
		imageNum = 0;
		shootSpell = false;
		int ticker = 0;
	}

	

	public void update() throws LineUnavailableException, IOException, UnsupportedAudioFileException {
		if(ticker == 3) {
		if(keyH.arrowLeft == true) {
			shootSpell = true;
			imageNum = 1;
			x = Player.xCurrent - speed;
			y = Player.yCurrent;
			Sound.playwindSpell();
		}
		if(shootSpell == true) {
			x -= speed;
			imageNum +=1;
			if(imageNum > 4) {
				imageNum = 1;
			}
		}
		ticker = 0;
	}	
		else {
			ticker += 1;
		}
	}
	
	public void draw(Graphics2D g2) {
		BufferedImage image = null;
		if(imageNum == 0) {
			image=null;
		} 
		if(imageNum == 1){
		image = w1;
		}
		if(imageNum == 2) {
			image = w2; 
		}
		if(imageNum == 3) {
			image = w3;
		}
		if(imageNum == 4) {
			image = w4;
		}
	
		g2.drawImage(image, x, y, 100, 60, null);
	}

	public void getPlayerImage() {
		try {
			w1 = ImageIO.read(getClass().getResourceAsStream("/player/WindHit1.png"));
			w2 = ImageIO.read(getClass().getResourceAsStream("/player/WindHit2.png"));
			w3 = ImageIO.read(getClass().getResourceAsStream("/player/WindHit3.png"));
			w4 = ImageIO.read(getClass().getResourceAsStream("/player/WindHit4.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public Rectangle getBounds() {
		return new Rectangle(x, y, 100, 60);
	}

}