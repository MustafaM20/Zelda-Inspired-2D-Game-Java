//Name- Mustafa Majeed and Ammar A
//Date 1/19/2024
//Class : Demon1
//Package Demon
package entity;

import java.awt.*; //all the imports
import main.GameFrame;
import main.GamePanel;
import main.KeyHandler;

import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class Demon extends Entity {

	GamePanel gp; // variable declaration
	KeyHandler keyH;
	int randnum;
	int ticker;
	int alternate;
	public static int xDemon;
	public static int yDemon;
	int xDifference;
	int yDifference;
	public boolean alive;

	public Demon(GamePanel gp) { // constructor
		this.gp = gp;
		randnum = 0;
		setDefaultValues();
		getPlayerImage();
		setDefaultStanding();
	}

	public void setDefaultValues() {
		x = 600;
		y = 600;// sets all the default values
		speed = 6;
		ticker = 0;
		alternate = 0;
		xDifference = 0;
		yDifference = 0;
		alive = true;
	}

	public void setDefaultStanding() { // sets defaultStanding as down
		direction = "down";
	}

	public void update() {

		if (ticker == 3) { // ticker is basically how many times per second does this occur, it helps make
							// animations smoother

			xDifference = Player.xCurrent - x; // calculates the difference between the demon and player
			yDifference = Player.yCurrent - y;

			if (Math.abs(xDifference) > Math.abs(yDifference)) { // depending on if ur closer x or y
				if (xDifference > 0) { // if ur closer by x, the demon first moves horizontally then the next time the /// if statmeent is true, the demons goes vertical
					// this creates a good walking animation for the demon
					direction = "right";
					x = x + speed;
				} else {
					direction = "left";
					x = x - speed;
				}
			} else {
				if (yDifference > 0) {
					direction = "down";
					y = y + speed;
				} else {
					direction = "up";
					y = y - speed;
				}
			}

			spriteCounter++; // this sprite counter alternates between the sprites of the demon

			if (spriteCounter > 1) { // essentially player image changes every 12 frames
				if (spriteNum == 1) {
					spriteNum = 2;
				} else if (spriteNum == 2) {
					spriteNum = 1;
				}
				spriteCounter = 0;
			}
			ticker = 0;
		} else {
			ticker += 1;
		}
	}

	public void draw(Graphics2D g2) {
		BufferedImage image = null;
		if (alive) { // if the demon is alive then the demon is drawm. this variable affected by the
						// level variable in the playerclass
			switch (direction) {
			case "up":
				if (spriteNum == 1) { // it alternates the animation depending on the case of which direction the
										// demon is facing
					image = du1;
				} // repeat this for all the directions
				if (spriteNum == 2) {
					image = du2;
				}
				break;
			case "down":
				if (spriteNum == 1) {
					image = dd1;
				}
				if (spriteNum == 2) {
					image = dd2;
				}
				break;
			case "left":
				if (spriteNum == 1) {
					image = dl1;
				}
				if (spriteNum == 2) {
					image = dl2;
				}
				break;
			case "right":
				if (spriteNum == 1) {
					image = dr1;
				}
				if (spriteNum == 2) {
					image = dr2;
				}
				break;
			}
		} else {
			image = null;
		}
		
		xDemon = x;
		yDemon = y;
		g2.drawImage(image, x, y, 120, 150, null); //you draw the demon based on the position and image which was decided by your direction
	}

	public void getPlayerImage() {
		try {
			du1 = ImageIO.read(getClass().getResourceAsStream("/demon/walkup1.png")); // import all the images
			du2 = ImageIO.read(getClass().getResourceAsStream("/demon/walkup2.png"));
			dd1 = ImageIO.read(getClass().getResourceAsStream("/demon/walkdown1.png"));
			dd2 = ImageIO.read(getClass().getResourceAsStream("/demon/walkdown2.png"));
			dr1 = ImageIO.read(getClass().getResourceAsStream("/demon/walkright1.png"));
			dr2 = ImageIO.read(getClass().getResourceAsStream("/demon/walkright2.png"));
			dl1 = ImageIO.read(getClass().getResourceAsStream("/demon/walkleft1.png"));
			dl2 = ImageIO.read(getClass().getResourceAsStream("/demon/walkleft2.png"));

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public Rectangle getBounds() { // creates bounds for the demons. these are the hitboxes we use
		return new Rectangle(x, y, 80, 100);
	}

	public Rectangle getBounds2() {
		return new Rectangle(x, y, 130, 150);
	}

}