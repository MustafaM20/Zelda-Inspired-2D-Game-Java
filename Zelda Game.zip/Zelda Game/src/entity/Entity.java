//Name- Mustafa Majeed and Ammar A
//Date 1/19/2024
//Class : Entity
//Package Entity
package entity;
import java.awt.image.BufferedImage;

public class Entity {
	
	public int x, y; //variables declaration
	public int speed;
	
	public BufferedImage up1, up2, down1, down2, left1, left2, right1, right2, attackright, attackleft, w1,w2,w3,w4;
	public String direction; //all the image and direction variables
	public BufferedImage du1, du2, dd1, dd2, dr1, dr2, dl1, dl2;
	
	public int spriteCounter = 0;
	public int spriteNum = 1;

}
