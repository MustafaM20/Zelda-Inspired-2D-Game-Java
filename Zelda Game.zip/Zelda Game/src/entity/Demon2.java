//Name- Mustafa Majeed and Ammar A
//Date 1/19/2024
//Class : Demon2
//Package Entity
package entity;

import java.awt.*;
import main.GameFrame;
import main.GamePanel;
import main.KeyHandler;

import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class Demon2 extends Entity { //The code is the exact same from the demon class but with different variables
	
	GamePanel gp;
	KeyHandler keyH;
	public int hp;
	int randnum;
	int ticker;
	public static int xDemon2;
	public static int yDemon2;
	int xDifference;
	int yDifference;
	public boolean level2;
	
	public Demon2(GamePanel gp) {
		this.gp = gp;
		randnum = 0;
		setDefaultValues();
		getPlayerImage();
		setDefaultStanding();
	}

 
  public void setDefaultValues() {
	x = 800;
	y = 300;
	speed = 7;
	hp = 1;
	ticker = 0;
	xDifference = 0;
	yDifference = 0;
}
  
  public void setDefaultStanding() {
		direction = "down";
  }
  
	public void update() {
		
		if (ticker == 2) {

			if (hp > 0) 
				xDifference = Player.xCurrent - x;
				yDifference = Player.yCurrent - y;

				if (Math.abs(xDifference) > Math.abs(yDifference)) {
					if (xDifference > 0) {
						direction = "right";
						x = x + speed;
					} else {
						direction = "left";
						x = x - speed;
					}
				} 
				else {
					if (yDifference > 0) {
						direction = "down";
						y = y + speed;
					} else {
						direction = "up";
						y = y - speed;
					}
				}

				spriteCounter++;

				if (spriteCounter > 1) { // essentially player image changes every 12 frames
					if (spriteNum == 1) {
						spriteNum = 2;
					} else if (spriteNum == 2) {
						spriteNum = 1;
					}
					spriteCounter = 0;
				}
				ticker = 0;
			} else {
				ticker += 1;
			}
		}
  
  public void draw(Graphics2D g2) {
		BufferedImage image = null;
		if(level2){
		switch (direction) {
		case "up":
			if(spriteNum == 1) {
				image = du1;}
			if(spriteNum == 2) {
				image = du2;
			}
			break;
		case "down":
			if(spriteNum == 1) {
				image = dd1;}
			if(spriteNum == 2) {
				image = dd2;
			}
			break;
		case "left":
			if(spriteNum == 1) {
				image = dl1;}
			if(spriteNum == 2) {
				image = dl2;
			}
			break;
		case "right":
			if(spriteNum == 1) {
				image = dr1;}
			if(spriteNum == 2) {
				image = dr2;
			}
			break;
		}
		}
		else{
			image = null;
		}
		xDemon2 = x;
		yDemon2 = y;
		g2.drawImage(image, x, y, 120, 150,null);
  }

public void getPlayerImage() {
	  try {
		  du1 = ImageIO.read(getClass().getResourceAsStream("/demon/walkup1.png"));
		  du2 = ImageIO.read(getClass().getResourceAsStream("/demon/walkup2.png"));
		  dd1 = ImageIO.read(getClass().getResourceAsStream("/demon/walkdown1.png"));
		  dd2 = ImageIO.read(getClass().getResourceAsStream("/demon/walkdown2.png"));
		  dr1 = ImageIO.read(getClass().getResourceAsStream("/demon/walkright1.png"));
		  dr2 = ImageIO.read(getClass().getResourceAsStream("/demon/walkright2.png"));
		  dl1 = ImageIO.read(getClass().getResourceAsStream("/demon/walkleft1.png"));
		  dl2 = ImageIO.read(getClass().getResourceAsStream("/demon/walkleft2.png"));
		
				  
	  }
	  catch(IOException e) {
		  e.printStackTrace();
	  }
  }

public Rectangle getBounds() {
	return new Rectangle(x, y, 80, 100);
}

public Rectangle getBounds2() {
	return new Rectangle(x, y, 130, 150);
}

}