//Name- Mustafa Majeed and Ammar A
//Date 1/19/2024
//Class : Player
//Package Entity
package entity;

import java.awt.*;
import main.GameFrame;
import main.GamePanel;
import main.KeyHandler;
import main.Sound;

import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;

public class Player extends Entity {

	Rectangle bounds; // variable declaration
	GamePanel gp;
	KeyHandler keyH;
	public int attackNum;
	public int x, y, speed, attackLetGo, xattack, yattack;
	public static int xCurrent; // static public variables for the fireballs
	public static int yCurrent;

	public Player(GamePanel gp, KeyHandler keyH) {
		this.gp = gp; // constructor
		this.keyH = keyH;
		setDefaultValues();
		getPlayerImage();
		setDefaultStanding();
	}

	public void setDefaultValues() {
		x = 100; // sets all the default values for the player
		y = 100;
		speed = 8;
		attackNum = 0;
		attackLetGo = 0;
	}

	public void setDefaultStanding() {
		direction = "down"; // gives him his standing animation
	}

	public void update() {

		if (keyH.upPressed == true || keyH.downPressed == true || keyH.leftPressed == true
				|| keyH.rightPressed == true) { // depending on which arrow key is clicked, the direction of link is
												// different
			if (keyH.upPressed == true) {
				direction = "up";
				y = y - speed;
				xCurrent = x;
				yCurrent = y;
			} else if (keyH.downPressed == true) {
				direction = "down";
				y = y + speed;
				xCurrent = x;
				yCurrent = y;
			} else if (keyH.leftPressed == true) {
				direction = "left";
				x = x - speed;
				xCurrent = x;
				yCurrent = y;
			} else if (keyH.rightPressed == true) {
				direction = "right";
				x = x + speed;
				xCurrent = x;
				yCurrent = y;
			}

			spriteCounter++;

			if (spriteCounter > 10) { // essentially player image changes every 10 frames
				if (spriteNum == 1) {
					spriteNum = 2;
				} else if (spriteNum == 2) {
					spriteNum = 1;
				}
				spriteCounter = 0;
			}

		}

	}

	public void draw(Graphics2D g2) throws LineUnavailableException, IOException, UnsupportedAudioFileException {
		BufferedImage image = null; // image is null for now
		attackNum = 0;
		switch (direction) { // depending on the direction of link the animation cycles betwen two sprites
		case "up":
			if (spriteNum == 1) {
				image = up1;
			}
			if (spriteNum == 2) {
				image = up2;
			}
			break;
		case "down":
			if (spriteNum == 1) {
				image = down1;
			}
			if (spriteNum == 2) {
				image = down2;
			}
			break;
		case "left":
			if (spriteNum == 1) {
				image = left1;
			}
			if (spriteNum == 2) {
				image = left2;
			}
			break;
		case "right":
			if (spriteNum == 1) {
				image = right1;
			}
			if (spriteNum == 2) {
				image = right2;
			}
			break;
		}

		if (keyH.spacePressed == true) { // if space bar is clicked, it activates the stab animation
			if (direction.equals("right") || direction.equals("up")) {
				image = attackright;
				attackNum = 1; // theres an attack number which indicates you attacked. for ur attack to count
								// again, you have to let go off space. this is to prevent u from holding space
								// and attacking infinitely
			} else if (direction.equals("left") || direction.equals("down")) {
				image = attackleft;
				attackNum = 1;
			}
			attackLetGo = 0;
			Sound.playSwordSlash();	
		}
		attackLetGo = 1;

		g2.drawImage(image, x, y, 50, 60, null); // draws the picture
	}

	public void getPlayerImage() {
		try {
			up1 = ImageIO.read(getClass().getResourceAsStream("/player/linkSpriteup.png")); // all the image imports
			up2 = ImageIO.read(getClass().getResourceAsStream("/player/linkSpriteup2.png"));
			down1 = ImageIO.read(getClass().getResourceAsStream("/player/linkSpritedown.png"));
			down2 = ImageIO.read(getClass().getResourceAsStream("/player/linkSpritedown2.png"));
			left1 = ImageIO.read(getClass().getResourceAsStream("/player/linkSpriteleft.png"));
			left2 = ImageIO.read(getClass().getResourceAsStream("/player/linkSpriteleft2.png"));
			right1 = ImageIO.read(getClass().getResourceAsStream("/player/linkSpriteright.png"));
			right2 = ImageIO.read(getClass().getResourceAsStream("/player/linkSpriteright2.png"));
			attackright = ImageIO.read(getClass().getResourceAsStream("/player/linkSpriteattackRight.png"));
			attackleft = ImageIO.read(getClass().getResourceAsStream("/player/linkSpriteattackLeft.png"));
			w4 = ImageIO.read(getClass().getResourceAsStream("/player/WindHit4.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public Rectangle getBounds() { // draws the two out of bounds for link
		return new Rectangle(x, y, 20, 20); // the smaller one is his hit box attacks
	}

	public Rectangle getBounds2() { // second one is for his sword attack
		return new Rectangle(x, y, 150, 150);
	}

}