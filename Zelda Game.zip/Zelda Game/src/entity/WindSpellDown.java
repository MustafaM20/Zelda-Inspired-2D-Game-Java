//Name- Mustafa Majeed and Ammar A
//Date 1/19/2024
//Class : wind spell down
//Package Entity

package entity;

import java.awt.*;
import main.GameFrame;
import main.GamePanel;
import main.KeyHandler;
import main.Sound;

import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;

public class WindSpellDown extends Entity {

	Rectangle bounds; //variable declaration
	GamePanel gp;
	KeyHandler keyH;
	public int attackNum;
	public int imageNum;
	public boolean shootSpell;
	public int ticker = 0;

	public WindSpellDown(GamePanel gp, KeyHandler keyH) { //constructor
		this.gp = gp;
		this.keyH = keyH;
		setDefaultValues();
		getPlayerImage();	
	}

	public void setDefaultValues() {
		x = 100; //default co-ords for spell
		y = 100;
		speed = 40; 
		imageNum = 0;
		shootSpell = false;
		int ticker = 0;
	}

	

	public void update() throws LineUnavailableException, IOException, UnsupportedAudioFileException {
		if(ticker == 3) { //spell travels every 
		if(keyH.arrowDown == true) { //if the arrow key is clicked
			shootSpell = true; //then the shootspell is true. only then will the spell move
			imageNum = 1;
			Sound.playwindSpell();
			x = Player.xCurrent; //the spell starts from the location of the player. to make it seem like they shot
			y = Player.yCurrent;
		}
		if(shootSpell == true) {
			y = y + speed; //the spell goes in the direction of the class name
			imageNum +=1; //the image num goes up to mimic animation
			if(imageNum > 4) {
				imageNum = 1;
			}
		}
		ticker = 0; //ticker get reset
	}	
		else {
			ticker += 1; //ticker goes up every time nothing occurs
		}
	}
	public void draw(Graphics2D g2) {
		BufferedImage image = null;
		if(imageNum == 0) { //if arrow key is clicked, nothing happens
			image=null;
		} 
		if(imageNum == 1){ //if arrow key is click then it cycles through the images.
		image = w1;
		}
		if(imageNum == 2) {
			image = w2; 
		}
		if(imageNum == 3) {
			image = w3;
		}
		if(imageNum == 4) {
			image = w4;
		}
	
		g2.drawImage(image, x, y, 100, 60, null); //the spell is drawn
	}

	public void getPlayerImage() {
		try {
			w1 = ImageIO.read(getClass().getResourceAsStream("/player/WindHit1.png")); //you import all the drawings
			w2 = ImageIO.read(getClass().getResourceAsStream("/player/WindHit2.png"));
			w3 = ImageIO.read(getClass().getResourceAsStream("/player/WindHit3.png"));
			w4 = ImageIO.read(getClass().getResourceAsStream("/player/WindHit4.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public Rectangle getBounds() { //the hit box of the spell is made
		return new Rectangle(x, y, 100, 60);
	}


}